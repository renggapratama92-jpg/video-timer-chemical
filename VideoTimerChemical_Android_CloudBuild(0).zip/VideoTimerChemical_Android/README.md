# Video Timer Chemical (Android)

Aplikasi Android sederhana untuk merekam video kalibrasi chemical dengan stopwatch tertanam di kiri bawah video.

## Build APK tanpa PC
Paket ini memakai GitHub Actions untuk build cloud. Perlu akun GitHub dan browser HP.

1. Ekstrak ZIP ini di HP menggunakan Files/ZArchiver.
2. Buat repository baru di github.com, misalnya `video-timer-chemical`.
3. Unggah semua isi folder project ke repository dengan struktur folder yang sama (termasuk folder `.github/workflows`).
4. Buka tab **Actions** di repository. Jika diminta, aktifkan GitHub Actions.
5. Pilih workflow **Build Video Timer Chemical APK**, tekan **Run workflow**.
6. Tunggu proses selesai. Buka hasil run yang sukses, bagian **Artifacts**, unduh `VideoTimerChemical-debug-apk`.
7. Ekstrak artifact ZIP, lalu instal `app-debug.apk` di HP. Izinkan instalasi dari sumber tersebut jika Android memintanya.

## Fitur
- Kamera belakang
- Stopwatch elapsed `menit:detik.sentidetik`
- Watermark tertanam di kiri bawah video
- Simpan hasil ke Galeri / Movies/VideoTimerChemical

## Catatan penting
- Ini adalah project sumber yang disiapkan untuk cloud build, bukan APK yang sudah dikompilasi atau diuji di perangkat.
- Format rekaman WebM. Pastikan pemutar video di HP mendukung WebM; VLC Android biasanya dapat memutarnya.
- Izin Kamera dan Mikrofon diperlukan. Mikrofon merekam suara sekitar.
- Durasi panjang menghasilkan file besar dan proses penyimpanan membutuhkan RAM. Uji dahulu rekaman singkat 10-20 detik.
- Jika build gagal, buka log Actions dan kirim tangkapan layar/log agar bisa diperbaiki.
