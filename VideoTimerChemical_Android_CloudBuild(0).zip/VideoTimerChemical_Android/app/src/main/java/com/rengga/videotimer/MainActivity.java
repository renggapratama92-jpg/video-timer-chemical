package com.rengga.videotimer;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.util.Base64;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST = 40;
    private WebView webView;
    private PermissionRequest pendingWebPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        webView.addJavascriptInterface(new VideoBridge(this), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (hasCameraAndAudioPermissions()) {
                        request.grant(request.getResources());
                    } else {
                        pendingWebPermission = request;
                        requestAndroidPermissions();
                    }
                });
            }
        });

        if (hasCameraAndAudioPermissions()) {
            loadApp();
        } else {
            requestAndroidPermissions();
        }
    }

    private boolean hasCameraAndAudioPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAndroidPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO},
                PERMISSION_REQUEST);
    }

    private void loadApp() {
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST) {
            if (hasCameraAndAudioPermissions()) {
                if (pendingWebPermission != null) {
                    pendingWebPermission.grant(pendingWebPermission.getResources());
                    pendingWebPermission = null;
                }
                loadApp();
            } else {
                Toast.makeText(this, "Izin kamera dan mikrofon diperlukan untuk merekam video.", Toast.LENGTH_LONG).show();
            }
        }
    }

    public class VideoBridge {
        private final Activity activity;
        VideoBridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface
        public void saveVideo(String base64Data, String fileName) {
            activity.runOnUiThread(() -> {
                try {
                    byte[] bytes;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        bytes = Base64.getDecoder().decode(base64Data);
                    } else {
                        bytes = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT);
                    }
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName);
                    values.put(MediaStore.Video.Media.MIME_TYPE, "video/webm");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoTimerChemical");
                        values.put(MediaStore.Video.Media.IS_PENDING, 1);
                    }
                    Uri uri = activity.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Gagal membuat file video");
                    try (OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("Gagal membuka file video");
                        out.write(bytes);
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.Video.Media.IS_PENDING, 0);
                        activity.getContentResolver().update(uri, done, null, null);
                    }
                    Toast.makeText(activity, "Video tersimpan di Galeri: Movies/VideoTimerChemical", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(activity, "Gagal menyimpan video: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
